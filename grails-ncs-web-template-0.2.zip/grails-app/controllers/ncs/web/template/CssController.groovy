package ncs.web.template

class CssController {

    def template = { }

    def print = { }
}
